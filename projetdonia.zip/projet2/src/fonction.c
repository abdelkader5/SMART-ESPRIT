#ifdef HAVE_CONFIG_H
#include <config.h>
#endif
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "fonction.h"
#include <gtk/gtk.h>
enum { 

ENOM,
EPRENOM,
ECLASSE,
EMAIL,
EID,
EADRESSE,
ETELMOBILE,
ETELPARENT,
ENCHAMBRE,
ESEXE,
ETYPE,
EETAGE,
COLUMNS,};



void ajouter(hebergement h){
FILE *f;
f=fopen("hebergement.txt","a+");
if (f!=NULL)
{fprintf(f,"%s %s %s %s %s %s %s %s %s %s %s %s \n",h.nom,h.prenom,h.classe,h.mail,h.id,h.adresse,h.TelMobile ,h.TelParent , h.nchambre  ,h.sexe,h.type ,h.etage);
    }
fclose(f);
}


void afficher(GtkWidget * liste)
{
      GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;
char nom [20];
char prenom[20];
char classe[20];
char mail[20];
char id[20];
char adresse[20] ;
char TelMobile[20] ;
char TelParent[20] ;
char nchambre[20] ;
char sexe[20];
char type[20] ;
char etage[20];
	store= NULL;
FILE *f;
	store=gtk_tree_view_get_model(liste);
	if (store==NULL){

	

	renderer = gtk_cell_renderer_text_new();
	       column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("classe",renderer,"text",ECLASSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mail",renderer,"text",EMAIL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	

	
	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",EADRESSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("TelMobile",renderer,"text",ETELMOBILE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("TelParent",renderer,"text",ETELPARENT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nchambre",renderer,"text",ENCHAMBRE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	

	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	
	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",EETAGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
        
        
        store=gtk_list_store_new(COLUMNS,G_TYPE_STRING ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,
        G_TYPE_STRING,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	}
	
	f=fopen("hebergement.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("hebergement.txt","a+");
while (fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s" ,nom,prenom,classe,mail,id,adresse,TelMobile,TelParent,nchambre,sexe,type,etage)!=EOF)
{gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,ENOM,nom,EPRENOM,prenom,ECLASSE,classe,EMAIL,mail,EID,id,EADRESSE,adresse,ETELMOBILE,TelMobile,ETELPARENT,TelParent,ENCHAMBRE,nchambre,ESEXE,sexe,ETYPE,type,EETAGE,etage,-1);}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);}}

void supprimer(hebergement h)
{char nom [20];
char prenom[20];
char classe[20];
char mail[20];
char id[20];
char adresse[20] ;
char TelMobile[20] ;
char TelParent[20] ;
char nchambre[20] ;
char sexe[20];
char type[20] ;
char etage[20];
FILE *f,*g;
f=fopen("hebergement.txt","r");
g=fopen("newhebergement.txt","w+");
if (g!=NULL)
{ if (f!=NULL)
{while 
(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage)!=EOF)
{ if(strcmp(h.id,id)!=0)
fprintf(g,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage);}}
fclose(f);
fclose(g);
remove("hebergement.txt");
rename("newhebergement.txt","hebergement.txt");}}

void modifier (hebergement h)
{   FILE *f;
    FILE *g;
   char nom [20];
char prenom[20];
char classe[20];
char mail[20];
char id[20];
char adresse[20] ;
char TelMobile[20] ;
char TelParent[20] ;
char nchambre[20] ;
char sexe[20];
char type[20] ;
char etage[20];
   f=fopen("hebergement.txt","r");
   g=fopen("modifierhebergement.txt","w+");
   if(f!=NULL)
     { if(g!=NULL)
         {while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage)!=EOF)
{if (strcmp(h.id,id)!=0)
{ fprintf(g,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage);}
else
{ fprintf(g,"%s %s %s %s %s %s %s %s %s %s %s %s\n",h.nom,h.prenom,h.classe,h.mail,h.id,h.adresse,h.TelMobile ,h.TelParent  ,h.nchambre ,sexe, h.type ,h.etage);}
}}}
fclose(f);
fclose(g);
remove("hebergement.txt");
rename("modifierhebergement.txt","hebergement.txt");}


void rechercher (hebergement h)
{
    
    FILE *f;
    FILE *p;
   char nom [20];
char prenom[20];
char classe[20];
char mail[20];
char id[20];
char adresse[20] ;
char TelMobile[20] ;
char TelParent[20] ;
char nchambre[20] ;
char sexe[20];
char type[20] ;
char etage[20];
   f=fopen("hebergement.txt","r");
   p=fopen("rechercherhebergement.txt","w+");
   if(f!=NULL)
     { if(p!=NULL)
         {while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage)!=EOF)
{if (strcmp(id,h.id)==0)
{ fprintf(p,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage);}}
fclose(f);
fclose(p);}
remove("hebergement.txt");
rename("rechercherhebergement.txt","hebergement.txt");}}

void vider(GtkWidget *liste)
{
GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;
store=NULL;
FILE *f=NULL;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{
	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",ENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",EPRENOM,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("classe",renderer,"text",ECLASSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("mail",renderer,"text",EMAIL,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",EID,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	

	
	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",EADRESSE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("TelMobile",renderer,"text",ETELMOBILE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("TelParent",renderer,"text",ETELPARENT,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


        renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("nchambre",renderer,"text",ENCHAMBRE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	

	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",ESEXE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

	
	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("type",renderer,"text",ETYPE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	renderer = gtk_cell_renderer_text_new();
	column=gtk_tree_view_column_new_with_attributes("etage",renderer,"text",EETAGE,NULL);
	gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
        }
        store=gtk_list_store_new(COLUMNS,G_TYPE_STRING ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,
        G_TYPE_STRING,G_TYPE_STRING ,G_TYPE_STRING ,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
int exist (char id [20])

{
char nom [20];
char prenom[20];
char classe[20];
char mail[20];
char adresse[20] ;
char TelMobile[20] ;
char TelParent[20] ;
char nchambre[20] ;
char sexe[20];
char type[20] ;
char etage[20];

hebergement h;

FILE *f;
int test = 0 ;
f=fopen("hebergement.txt","r");
if(f!=NULL) {
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage)!=EOF)
{
if((strcmp(h.id,id)==0))
test=1 ;
else 
test=0;
 } }
fclose(f);

return test;
}




int nombre_etudiants (char etagenv[20])
{
FILE *f=NULL;
int k=0;
char nom [20];
char prenom[20];
char classe[20];
char mail[20];
char id[20];
char adresse[20] ;
char TelMobile[20] ;
char TelParent[20] ;
char nchambre[20] ;
char sexe[20];
char type[20] ;
char etage[20];
f=fopen("hebergement.txt","r");
if(f!=NULL){
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s %s\n",nom,prenom,classe,mail,id,adresse,TelMobile ,TelParent  ,nchambre ,sexe, type ,etage)!=EOF)
{
if(strcmp(etagenv,etage)==0)
k+=1;}
fclose(f);
}
return (k);
}


