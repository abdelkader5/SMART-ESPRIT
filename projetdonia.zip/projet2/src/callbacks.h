#include <gtk/gtk.h>


/*void
on_button2_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_radiobutton1_clicked                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_clicked                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button3_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button4_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button5_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button1_clicked                     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button12_clicked                    (GtkButton       *button,
                                        gpointer         user_data);



void
on_button16_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_check_femme_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_check_homme_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2____deux_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button18_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button19_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button20_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button24_clicked                    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button15_validean_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button50_valide_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_nbdetudiant_row_activated (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button19_ajouter_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);

void
on_button20_annuleraj_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_indiv_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button21_ajouterGes_clicked         (GtkButton       *button,
                                        gpointer         user_data);

void
on_button22_modidifierges_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button23_supprimerges_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_boton_payer_clicked                 (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_indiv_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_ruturn_clicked                      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modidifier_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvalidermodifier_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_buttonvaliderchercher_clicked       (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_validesupprimer_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_Afficher_clicked                    (GtkButton       *button,
                                        gpointer         user_data);
void
on_treeview1nbetudiant_row_activated   (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_Affichert_clicked                   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button__Affficher_clicked           (GtkButton       *button,
                                        gpointer         user_data);


/*void
on_spinbutton1_editing_done            (GtkCellEditable *celleditable,
                                        gpointer         user_data);*/

/*void
on_buttonfinale_clicked                (GtkButton       *button,
                                        gpointer         user_data);*/

void
on_treeviewnew_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button__affficher_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_donnernb_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifierd_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_button__modifier_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data);
