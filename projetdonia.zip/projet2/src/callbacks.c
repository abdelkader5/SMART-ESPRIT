#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"

int x,y;
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{ if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}

}





void
on_radiobutton1_indiv_toggled          (GtkToggleButton *togglebutton,
                                         gpointer         user_data)


{if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=1;}
}
void
on_radiobutton2____deux_toggled        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{ if ( gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
{x=2;}

}
void
on_check_femme_toggled                 (GtkToggleButton *togglebutton,
                                        gpointer         user_data)

{ if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{y=1;}
}
void
on_check_homme_toggled                 (GtkToggleButton *togglebutton,
                                         gpointer         user_data)


{ if ( gtk_toggle_button_get_active(GTK_CHECK_BUTTON (togglebutton)))
{y=2;}
}



void
on_button19_ajouter_clicked             (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
hebergement h;
GtkWidget *nom,*prenom,*classe, *mail,*id,*adresse, *TelMobile, *TelParent, *nchambre  , *etage ;

nom= lookup_widget (objet_graphique, "entry18");
prenom= lookup_widget (objet_graphique, "entry19");
classe = lookup_widget (objet_graphique, "entry20");
mail = lookup_widget (objet_graphique, "entry21");
id= lookup_widget (objet_graphique, "entry22");
adresse = lookup_widget (objet_graphique, "entry23");
TelMobile= lookup_widget (objet_graphique, "entry24");
TelParent = lookup_widget (objet_graphique, "entry25");
nchambre = lookup_widget (objet_graphique, "entry_nchambre");
if (y==1){
strcpy(h.sexe,"femme");}
else{
strcpy(h.sexe,"homme");}
if (x==1){
strcpy(h.type,"indiv");}
else{
strcpy(h.type,"double");}
etage = lookup_widget (objet_graphique, "combobox__etage");
strcpy(h.nom, gtk_entry_get_text(GTK_ENTRY(nom)));
strcpy(h.prenom, gtk_entry_get_text(GTK_ENTRY(prenom)));
strcpy(h.classe, gtk_entry_get_text(GTK_ENTRY(classe)));
strcpy(h.mail, gtk_entry_get_text(GTK_ENTRY(mail)));
strcpy(h.id, gtk_entry_get_text(GTK_ENTRY(id)));
strcpy(h.adresse, gtk_entry_get_text(GTK_ENTRY(adresse)));
strcpy(h.TelMobile, gtk_entry_get_text(GTK_ENTRY(TelMobile)));
strcpy(h.TelParent, gtk_entry_get_text(GTK_ENTRY(TelParent)));
strcpy(h.nchambre, gtk_entry_get_text(GTK_ENTRY(nchambre)));
strcpy(h.etage, gtk_combo_box_get_active_text(GTK_COMBO_BOX(etage)));
ajouter(h);}
void
on_button__modifier_clicked            (GtkWidget       *objet_graphique,
                                        gpointer         user_data)
{
hebergement h;
GtkWidget *input1,*input2,*input3, *input4,*input5,*input6, *input7, *input8, *input9  , *input10 ;

input1= lookup_widget (objet_graphique, "entry_nom");
input2= lookup_widget (objet_graphique, "entry_prenom");
input3= lookup_widget (objet_graphique, "entry_classe");
input4= lookup_widget (objet_graphique, "entry_mail");
input5= lookup_widget (objet_graphique, "entry_id");
input6 = lookup_widget (objet_graphique, "entry_adresse");
input7= lookup_widget (objet_graphique, "entry_TelMobile");
input8 = lookup_widget (objet_graphique, "entry_TelParent");
input9= lookup_widget (objet_graphique, "entry_nchambremodif");
if (y==1){
strcpy(h.sexe,"femme");}
else{
strcpy(h.sexe,"homme");}
if (x==1){
strcpy(h.type,"indiv");}
else{
strcpy(h.type,"double");}
input10= lookup_widget (objet_graphique, "combobox_etagemodif");
strcpy(h.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(h.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(h.classe, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(h.mail, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(h.id, gtk_entry_get_text(GTK_ENTRY(input5)));
strcpy(h.adresse, gtk_entry_get_text(GTK_ENTRY(input6)));
strcpy(h.TelMobile, gtk_entry_get_text(GTK_ENTRY(input7)));
strcpy(h.TelParent, gtk_entry_get_text(GTK_ENTRY(input8)));
strcpy(h.nchambre, gtk_entry_get_text(GTK_ENTRY(input9)));
strcpy(h.etage, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input10)));
modifier(h);
}



void
on_button_validesupprimer_clicked      (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *id;
char ident[200];
hebergement h;
id= lookup_widget (button, "entry14");
strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(id)));
supprimer(h);
}

void
on_buttonvaliderchercher_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{hebergement h;
GtkWidget *input;
GtkWidget *existe;
input=lookup_widget(button,"entry_identifiantchercher");
existe=lookup_widget(button,"label101");
strcpy(h.id,gtk_entry_get_text(GTK_ENTRY(input)));
if(exist(h.id)==0)
{gtk_label_set_text(GTK_LABEL(existe),"ID non existant");
}
else 
{
    gtk_label_set_text(GTK_LABEL(existe),"ID existant");
}
rechercher(h);
}

void
on_button_donnernb_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{

char etage[20];
int n ;
char msg[30];
GtkWidget *input1, *output;
input1=lookup_widget(button,"combobox_etagenb");
strcpy(etage,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));
n=nombre_etudiants(etage);
sprintf(msg, "%d", n);
output = lookup_widget(button, "labelnb");
gtk_label_set_text(GTK_LABEL(output),msg);
}
void
on_button__affficher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{


GtkWidget *fenetre_ajout;
GtkWidget *fenetre_afficher;
GtkWidget *treeviewnew;
//fenetre_ajout=lookup_widget(button,"interface");
fenetre_afficher=lookup_widget(button,"interface");

treeviewnew=lookup_widget(fenetre_afficher,"treeviewnew");
afficher(treeviewnew);
}

void
on_treeviewnew_row_activated           (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{ GtkTreeIter iter;
gchar* nom;
gchar* prenom;
gchar* classe;
gchar* mail;
gchar* id;
gchar* adresse ;
gchar* TelMobile ;
gchar* TelParent ;
gchar* nchambre ;

gchar* sexe;
gchar* type ;
gchar* etage;
hebergement h;
GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter,path))
{
gtk_tree_model_get(GTK_LIST_STORE(model), &iter , 0 , &nom , 1 ,&prenom, 2 , &classe , 3 , &mail , 4 ,&id, 5 , &adresse , 6 , &TelMobile, 7 , &TelParent , 8 , &nchambre , 9 , &sexe , 10 , &type , 11 , &etage, -1);
strcpy(h.nom,nom);
strcpy(h.prenom,prenom);
strcpy(h.classe,classe);
strcpy(h.mail,mail);
strcpy(h.id,id);
strcpy(h.adresse,adresse);
strcpy(h.TelMobile,TelMobile);
strcpy(h.TelParent,TelParent);
strcpy(h.nchambre,nchambre);
strcpy(h.sexe,sexe);
strcpy(h.type,type);
strcpy(h.etage,etage);
//supprimer(h);
afficher(treeview);


}

}







/*void
on_spinbutton1_editing_done            (GtkCellEditable *celleditable,
                                        gpointer         user_data)
{

}


void
on_buttonfinale_clicked                (GtkButton       *button,
                                        gpointer         user_data)
{
hebergement h;
GtkWidget *input1 ;
input1 = lookup_widget(button,"combobox4");

strcpy(h.pay,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input1)));

ajouter(h);
}*/
















