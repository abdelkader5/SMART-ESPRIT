#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h> 
#include "etud.h"
enum{
NOM,
PRENOM,
CIN,
NAISSANCE,
AGE,
SEXE,
FILLIERE,
NIVEAU,
EMAIL,
TELEPHONE,
ADRESSE,
COLUMNS
};



void ajouter_etudiant(etudiant e)
{
FILE *f;
f=fopen("etudiantadmin.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %d/%d/%d %s %s %s %s %s %s %s \n",e.nom,e.prenom,e.cin,e.d.jour,e.d.mois,e.d.annee,e.age,e.sexe,e.filiere,e.niveau,e.email,e.telephone,e.adresse);
}
fclose(f);
}

void afficher_etudiant(GtkWidget * liste ){

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom[30];
char prenom[30];
char cin[30];
char naissance [30];
char age [30] ;
char sexe[30];
char filiere[30];
char niveau[30];
char email[30];
char telephone [30];
char adresse[30];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("naissance",renderer,"text",NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("age",renderer,"text",AGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("filiere",renderer,"text",FILLIERE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("niveau",renderer,"text",NIVEAU,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",TELEPHONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",ADRESSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("etudiantadmin.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("etudiantadmin.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,naissance,age,sexe,filiere,niveau,email,telephone,adresse)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,CIN,cin,NAISSANCE,naissance,AGE,age,SEXE,sexe,FILLIERE,filiere,NIVEAU,niveau,EMAIL,email,TELEPHONE,telephone,ADRESSE,adresse,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}




void modifier_etudiant(etudiant e)
{

FILE *f;
FILE *t;

etudiant s ;

f=fopen("etudiantadmin.txt","r");
t=fopen("etudiantadmintemp.text","a");

    if (f!=NULL || t!=NULL)
    {
    while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s %s %s %s %s \n",s.nom,s.prenom,s.cin,&s.d.jour,&s.d.mois,&s.d.annee,s.age,s.sexe,s.filiere,s.niveau,s.email,s.telephone,s.adresse)!=EOF)
    {
if(strcmp(s.cin,e.cin)==0)
        {
fprintf(t,"%s %s %s %d/%d/%d %s %s %s %s %s %s %s \n",e.nom,e.prenom,e.cin,e.d.jour,e.d.mois,e.d.annee,e.age,e.sexe,e.filiere,e.niveau,e.email,e.telephone,e.adresse);
}
else
fprintf(t,"%s %s %s %d/%d/%d %s %s %s %s %s %s %s \n",s.nom,s.prenom,s.cin,s.d.jour,s.d.mois,s.d.annee,s.age,s.sexe,s.filiere,s.niveau,s.email,s.telephone,s.adresse);
    }
    }
fclose(t);
fclose(f);
remove("etudiantadmin.txt");
rename("etudiantadmintemp.text","etudiantadmin.txt");
}


void rempliraffiche(char nom[30],char prenom[30],char cin[30],int *jour ,int *mois,int *annee,char age[30],char sexe[30],char filiere[30],char niveau[30],char email[30],char telephone[30],char adresse[30]){
 etudiant s ;
FILE *f;
    f=fopen("etudiantadmin.txt", "r");
    
    while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s %s %s %s %s \n",s.nom,s.prenom,s.cin,&s.d.jour,&s.d.mois,&s.d.annee,s.age,s.sexe,s.filiere,s.niveau,s.email,s.telephone,s.adresse)!=EOF) 
{
        if(strcmp(s.cin,cin)==0) { strcpy(nom,s.nom);
					strcpy(prenom,s.prenom);
					strcpy(age,s.age);
					strcpy(telephone,s.telephone);
					strcpy(adresse,s.adresse);
					strcpy(email,s.email);
					jour=&s.d.jour;
					mois=&s.d.mois;
					annee=&s.d.annee;
//					sprintf(date,"%d/%d/%d",s.d.jour,s.d.mois,s.d.annee);
//					printf("%s",date);
					strcpy(filiere,s.filiere);
					strcpy(niveau,s.niveau);
					break;

}



}
fclose(f);
}

int exist_etudiant(char* cin){
FILE*f=NULL;
etudiant e;
f=fopen("etudiantadmin.txt","r");// ouverture du fichier plante en  mode lecture 
while(fscanf(f,"%s  \n",e.cin)!=EOF){
if(strcmp(e.cin,cin)==0)
return 1;   //cin existe deja 
}
fclose(f);
return 0;
}

void chercher_etudiant(etudiant e)
{

FILE* f;
FILE* f1;
char nom[30];
char prenom[30];
char cin[30];
char naissance [30];
char age [30] ;
char sexe[30];
char filiere[30];
char niveau[30];
char email[30];
char telephone [30];
char adresse[30];

f=fopen("etudiantadmin.txt","r");
f1=fopen("etudiantadmincher.txt","w");
  while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,naissance,age,sexe,filiere,niveau,email,telephone,adresse)!=EOF)
{
if (strcmp(e.cin,cin)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,naissance,age,sexe,filiere,niveau,email,telephone,adresse);
}
}
fclose(f);
fclose(f1);
}


void afficher_etudiant_chercher(GtkWidget *liste)
{
      GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

char nom[30];
char prenom[30];
char cin[30];
char naissance [30];
char age [30] ;
char sexe[30];
char filiere[30];
char niveau[30];
char email[30];
char telephone [30];
char adresse[30];

	store=NULL;
	
	FILE *f;
 
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("naissance",renderer,"text",NAISSANCE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("age",renderer,"text",AGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("filiere",renderer,"text",FILLIERE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column); 
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("niveau",renderer,"text",NIVEAU,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",TELEPHONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",ADRESSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);



	}
		store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f = fopen("etudiantadmincher.txt","r");
	if(f==NULL)
	{
	return;
	}
	else
	{
	 f=fopen("etudiantadmincher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,naissance,age,sexe,filiere,niveau,email,telephone,adresse)!=EOF)
		{
		gtk_list_store_append(store,&iter);
		 gtk_list_store_set(store,&iter ,NOM,nom,PRENOM,prenom,CIN,cin,NAISSANCE,naissance,AGE,age,SEXE,sexe,FILLIERE,filiere,NIVEAU,niveau,EMAIL,email,TELEPHONE,telephone,ADRESSE,adresse,-1);		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);

	}
}




