#include <gtk/gtk.h>
typedef struct
{
int jour ;
int mois;
int annee;
}naissance;
typedef struct
{
char nom[30];
char prenom[30];
char cin[30];
naissance d;
char age [30] ;
char sexe[30];
char filiere[30];
char niveau[30];
char email[30];
char telephone [30];
char adresse[30];
}etudiant;
int o;
int E;

void ajouter_etudiant(etudiant e);
void afficher_etudiant(GtkWidget *liste );
void modifier_etudiant(etudiant e);
void rempliraffiche(char nom[30],char prenom[30],char cin[30],int *jour ,int *mois,int *annee,char age[30],char sexe[30],char filiere[30],char niveau[30],char email[30],char telephone[30],char adresse[30]);

void chercher_etudiant(etudiant e);
void afficher_etudiant_chercher(GtkWidget *liste);
