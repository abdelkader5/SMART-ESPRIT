#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h> 
#include "personne.h"
enum{
NOM,
PRENOM,
CIN,
D,
AGE,
SEXE,
EMAIL,
TELEPHONE,
ADRESSE,
ROLE,
COLUMNS
};



void ajouter_personne(personne p)
{
FILE *f;
f=fopen("utilisateur.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %d/%d/%d %s %s %s %s %s %s\n",p.nom,p.prenom,p.cin,p.d.jour,p.d.mois,p.d.annee,p.age,p.sexe,p.email,p.telephone,p.adresse, p.role);
}
fclose(f);
}

void afficher_personne(GtkWidget * liste ){

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom [30];
char prenom [30];
char cin [30];
char date[30];
char age[30];
char sexe[30];
char telephone [30];
char adresse[30];
char email[30];
char role[30];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",D,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("age",renderer,"text",AGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",TELEPHONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",ADRESSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",ROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("utilisateur.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("utilisateur.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,date,age,sexe,email,telephone,adresse,role)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,PRENOM,prenom,CIN,cin,D,date,AGE,age,SEXE,sexe,EMAIL,email,TELEPHONE,telephone,ADRESSE,adresse,ROLE,role,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void vider(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter	iter;
GtkListStore *store;
	
char nom [30];
char prenom [30];
char cin [30];
char date[30];
char age[30];
char sexe[30];
char telephone [30];
char adresse[30];
char email[30];
char role[30];
store=NULL ;

FILE *f;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
	{
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",D,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("age",renderer,"text",AGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",TELEPHONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",ADRESSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",ROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
}

store=gtk_list_store_new (COLUMNS, G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
gtk_list_store_append (store, &iter);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));

}

void modifier_personne(personne p)
{
FILE *f;
FILE *t;

personne s ;

f=fopen("utilisateur.txt","r");
t=fopen("temp.text","a");

    if (f!=NULL || t!=NULL)
    {
    while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s %s %s %s \n",s.nom,s.prenom,s.cin,&s.d.jour,&s.d.mois,&s.d.annee,s.age,s.sexe,s.email,s.telephone,s.adresse,s.role)!=EOF)
    {
if(strcmp(s.cin,p.cin)==0)
        {
fprintf(t,"%s %s %s %d/%d/%d %s %s %s %s %s %s \n",p.nom,p.prenom,p.cin,p.d.jour,p.d.mois,p.d.annee,p.age,p.sexe,p.email,p.telephone,p.adresse,p.role);
}
else
fprintf(t,"%s %s %s %d/%d/%d %s %s %s %s %s %s \n",s.nom,s.prenom,s.cin,s.d.jour,s.d.mois,s.d.annee,s.age,s.sexe,s.email,s.telephone,s.adresse,s.role);
    }
    }
fclose(t);
fclose(f);
remove("utilisateur.txt");
rename("temp.text","utilisateur.txt");
}



int verifier_CIN_inscrit(char cin[30])
{ 
FILE*f=NULL;
personne p;
f=fopen("utilisateur.txt","r");
while(fscanf(f,"%s %s %s %s %s \n",p.nom,p.prenom,p.cin,p.sexe,p.role)!=EOF){
if((strcmp(p.cin,cin)==0)||(strcmp(cin,"admin")==0))
return 1; //existe   
}
fclose(f);
return 0; //n'existe pas
}




int verifier_PASSEWORD_inscrit(char passeword[30])
{ 
if(strcmp("admin",passeword)==0)
	{
	return 0; //Administrateur  
	}else
if(strcmp("foyer",passeword)==0)
	{
	return 1; //agent foyer
	}else
if(strcmp("stock",passeword)==0)
	{
	return 2; //agent stock  
	}else
if(strcmp("technicien",passeword)==0)
	{
	return 3; //technicien  
	}else
if(strcmp("nutristionist",passeword)==0)
	{
	return 4; //nutristionist 
	}else
if(strcmp("reclamation",passeword)==0)
	{
	return 5; //reclamation  
	}else
{ return 8; 
}

}




int verifier_ACCEE_inscrit(char cin[30])
{
FILE*f=NULL;
personne p;
f=fopen("utilisateur.txt","r");
 while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s %s %s %s\n",p.nom,p.prenom,p.cin,&p.d.jour,&p.d.mois,&p.d.annee,p.age,p.sexe,p.email,p.telephone,p.adresse, p.role)!=EOF)
	{
	if (strcmp(p.cin,cin)==0)
		{
		if (strcmp(p.role,"administrateur")==0)
		return 1;
		if (strcmp(p.role,"agentfoyer")==0)
		return 2;
		if (strcmp(p.role,"agentstock")==0)
		return 3;
		if (strcmp(p.role,"technicien")==0)
		return 4;
		if (strcmp(p.role,"nutristionist")==0)
		return 5;
		if (strcmp(p.role,"reclamation")==0)
		return 6;
		
		}
	}
}


int exist_cin(char* cin){
FILE*f=NULL;
personne p;
f=fopen("utilisateur.txt","r");
while(fscanf(f,"%s  \n",p.cin)!=EOF){
if(strcmp(p.cin,cin)==0)
return 1;   //cin existe deja 
}
fclose(f);
return 0;
}


void chercher_personne(personne p)  
{
FILE* f;
FILE* f1;
char nom [30];
char prenom [30];
char cin [30];
char date[30];
char age[30];
char sexe[30];
char telephone [30];
char adresse[30];
char email[30];
char role[30];

f=fopen("utilisateur.txt","r");
f1=fopen("utilisateurcher.txt","w");
  while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,date,age,sexe,email,telephone,adresse,role)!=EOF)
{
if (strcmp(p.cin,cin)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s %s %s %s \n",nom,prenom,cin,date,age,sexe,email,telephone,adresse,role);
}
}
fclose(f);
fclose(f1);
}


void afficher_personne_chercher(GtkWidget *liste)
{
      GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

char nom [30];
char prenom [30];
char cin [30];
char date[30];
char age[30];
char sexe[30];
char telephone [30];
char adresse[30];
char email[30];
char role[30];

	store=NULL;
	
	FILE *f;
 
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prenom",renderer,"text",PRENOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("cin",renderer,"text",CIN,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",D,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("age",renderer,"text",AGE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("sexe",renderer,"text",SEXE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("email",renderer,"text",EMAIL,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("telephone",renderer,"text",TELEPHONE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("adresse",renderer,"text",ADRESSE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);
renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("role",renderer,"text",ROLE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);


	}
		store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f = fopen("utilisateurcher.txt","r");
	if(f==NULL)
	{
	return;
	}
	else
	{
	 f=fopen("utilisateurcher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s %s %s %s  \n",nom,prenom,cin,date,age,sexe,email,telephone,adresse,role)!=EOF)
		{
		gtk_list_store_append(store,&iter);
		 gtk_list_store_set(store,&iter ,NOM,nom,PRENOM,prenom,CIN,cin,D,date,AGE,age,SEXE,sexe,EMAIL,email,TELEPHONE,telephone,ADRESSE,adresse,ROLE,role,-1);		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);

	}
}



void rechercheraffiche(char nom[],char prenom[],char cin[],int *jour ,int *mois,int *annee,char age[],char telephone[],char adresse[] ,char email[],char role[]){
 personne s ;
FILE *f;
    f=fopen("utilisateur.txt", "r");
    
    while(fscanf(f,"%s %s %s %d/%d/%d %s %s %s %s %s %s \n",s.nom,s.prenom,s.cin,&s.d.jour,&s.d.mois,&s.d.annee,s.age,s.sexe,s.email,s.telephone,s.adresse,s.role)!=EOF) 
{
        if(strcmp(s.cin,cin)==0) { strcpy(nom,s.nom);
					strcpy(prenom,s.prenom);
					strcpy(age,s.age);
					strcpy(telephone,s.telephone);
					strcpy(adresse,s.adresse);
					strcpy(email,s.email);
					jour=&s.d.jour;
					mois=&s.d.mois;
					annee=&s.d.annee;
//					sprintf(date,"%d/%d/%d",s.d.jour,s.d.mois,s.d.annee);
//					printf("%s",date);
					strcpy(role,s.role);
					break;

}



}
fclose(f);
}







