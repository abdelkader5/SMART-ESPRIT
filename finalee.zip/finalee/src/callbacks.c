#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif
#include <gtk/gtk.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "personne.h"
#include "etud.h"


void
on_button_go_to_login_clicked          (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_login ;
GtkWidget *fenetre_dashboard;

fenetre_dashboard=lookup_widget(objet,"fenetre_dashboard");
gtk_widget_destroy(fenetre_dashboard);
fenetre_dashboard=lookup_widget(objet,"fenetre_dashboard");
fenetre_login=create_fenetre_login();
gtk_widget_show(fenetre_login);
}


void
on_button_login_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *cin,*passeword,*resultat;
GtkWidget *fenetre_login ;
GtkWidget *fenetre_dashboard;
GtkWidget *fenetre_tableau;
personne p;
char mot_de_passe[30];
char cin1[30];
int verif_cin_inscrit,verif_passeword_inscrit,verif_accee_inscrit;
resultat=lookup_widget(objet,"label_resultat");
cin=lookup_widget(objet,"entry_login_nom_verif");
passeword=lookup_widget(objet,"entry_login_motdepasse_verif");
strcpy(cin1,gtk_entry_get_text(GTK_ENTRY(cin)));
strcpy(mot_de_passe,gtk_entry_get_text(GTK_ENTRY(passeword)));
verif_cin_inscrit=verifier_CIN_inscrit(cin1);
verif_passeword_inscrit=verifier_PASSEWORD_inscrit(mot_de_passe);
verif_accee_inscrit=verifier_ACCEE_inscrit(cin1);
GdkColor color;
gdk_color_parse("red",&color);
gtk_widget_modify_fg(resultat,GTK_STATE_NORMAL,&color);
if(verif_passeword_inscrit==8)
gtk_label_set_text(GTK_LABEL(resultat),"Mot de passe incorrecte");
if(verif_cin_inscrit==0)
gtk_label_set_text(GTK_LABEL(resultat),"CIN n'éxiste pas");


////////////////////////////////////////////////////////////////
if(verif_cin_inscrit==1)
{
if(verif_passeword_inscrit==0)
{
GtkWidget *fenetre_login;
GtkWidget *fenetre_navigateur;
fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);
}else
gtk_label_set_text(GTK_LABEL(resultat),"Accèe interdit");

if(verif_passeword_inscrit==1)
{
GtkWidget *fenetre_liste_dalarme;
GtkWidget *fenetre_login;
fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);
fenetre_liste_dalarme=create_fenetre_liste_dalarme();
gtk_widget_show(fenetre_liste_dalarme);
}else
gtk_label_set_text(GTK_LABEL(resultat),"Accèe interdit");

if(verif_passeword_inscrit==2)
{
GtkWidget *fenetre_liste_dalarme;
GtkWidget *fenetre_login;
fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);
fenetre_liste_dalarme=create_fenetre_liste_dalarme();
gtk_widget_show(fenetre_liste_dalarme);
}else
gtk_label_set_text(GTK_LABEL(resultat),"Accèe interdit");
if(verif_passeword_inscrit==3)
{
GtkWidget *fenetre_liste_dalarme;
GtkWidget *fenetre_login;
fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);
fenetre_liste_dalarme=create_fenetre_liste_dalarme();
gtk_widget_show(fenetre_liste_dalarme);
}else
gtk_label_set_text(GTK_LABEL(resultat),"Accèe interdit");
if(verif_passeword_inscrit==4)
{
GtkWidget *fenetre_liste_dalarme;
GtkWidget *fenetre_login;
fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);
fenetre_liste_dalarme=create_fenetre_liste_dalarme();
gtk_widget_show(fenetre_liste_dalarme);
}else
gtk_label_set_text(GTK_LABEL(resultat),"Accèe interdit");
if(verif_passeword_inscrit==5)
{
GtkWidget *fenetre_liste_dalarme;
GtkWidget *fenetre_login;
fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);
fenetre_liste_dalarme=create_fenetre_liste_dalarme();
gtk_widget_show(fenetre_liste_dalarme);
}else
gtk_label_set_text(GTK_LABEL(resultat),"Accèe interdit");
}
}


void
on_button_retour_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{GtkWidget *fenetre_login ;
GtkWidget *fenetre_dashboard;

fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);
fenetre_login=lookup_widget(objet,"fenetre_login");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);

}


void
on_button_quitter_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}
void
on_button_inscription_clicked          (GtkButton       *objet,
                                        gpointer         user_data)
{

personne p;
GtkWidget *input1,*input2,*input3,*input4,*input5 ,*input6,*input7 ,*input8,*input9,*input10,*input11,*input12,*input13,*success ;
GtkWidget *fenetre_tableau,*fenetre_msg_ajouter;

success=lookup_widget(objet,"label_ajout_sec");

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");

input1=lookup_widget (objet, "entry_nom");
input2=lookup_widget (objet, "entry_prenom");
input3=lookup_widget (objet, "entry_cin");
input4=lookup_widget (objet, "radiobutton_homme");
input5=lookup_widget (objet, "radiobutton_femme");
input6=lookup_widget (objet, "comboboxentry_Role_inscrip");
input7=lookup_widget (objet, "spinbutton_date_jour_inscrip");
input8=lookup_widget (objet, "spinbutton_date_annee_inscrip");
input9=lookup_widget (objet, "spinbutton_mois_inscri");
input10=lookup_widget (objet, "entry_age_iscrip");


input11=lookup_widget (objet, "entry_telephone_inscrip");
input12=lookup_widget (objet, "entry_email_inscrip");
input13=lookup_widget (objet, "entry_adresse_inscrip");


strcpy(p.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.cin, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.age, gtk_entry_get_text(GTK_ENTRY(input10)));

strcpy(p.telephone, gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(p.adresse, gtk_entry_get_text(GTK_ENTRY(input13)));
strcpy(p.email, gtk_entry_get_text(GTK_ENTRY(input12)));

p.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
p.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
p.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));



strcpy(p.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));
if (x==1)
{
strcpy(p.sexe,"homme");
}
if (x==2)
{
strcpy(p.sexe,"femme");
}

gtk_label_set_text(GTK_LABEL(success),"Ajout réuissite");
ajouter_personne(p);

}
void
on_treeview1_row_activated             (GtkTreeView     *treeview1,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar *nom;
gchar *prenom;
gchar *cin;
gchar *sexe;
gchar *role;
personne p;
 GtkTreeModel *model=gtk_tree_view_get_model(treeview1);
if (gtk_tree_model_get_iter(model,&iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,3,&cin,4,&role,-1);
strcpy(p.nom,nom);
strcpy(p.prenom,prenom);
strcpy(p.cin,cin);
strcpy(p.sexe,sexe);
strcpy(p.role,role);

afficher_personne(treeview1);
}
}
void
on_button_actualiser_clicked           (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_tableau,*w1;
GtkWidget *treeview1;

GtkNotebook  *notebook3 ;

w1=lookup_widget(objet,"fenetre_tableau");
fenetre_tableau=create_fenetre_tableau();
gtk_widget_show(fenetre_tableau);
gtk_widget_hide(w1);
treeview1=lookup_widget(fenetre_tableau,"treeview1");
afficher_personne(treeview1);
/*notebook3=(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
gint page = gtk_notebook_get_current_page (notebook3); 
gtk_notebook_set_current_page (notebook3,2);*/


}


void
on_button_afficher_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{

GtkWidget *fenetre_tableau;
GtkWidget *treeview1;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_show(fenetre_tableau);

treeview1=lookup_widget(fenetre_tableau,"treeview1");
afficher_personne(treeview1);


}


void
on_button_modifier_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
personne p;
GtkWidget *input1,*input2,*input3,*input4,*input5 ,*input6,*input7 ,*input8,*input9,*input10,*input11,*input12,*input13,*success ;
GtkWidget *fenetre_tableau;

success=lookup_widget(objet,"label_modifier_msg");

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");

input1=lookup_widget (objet, "entry_modifier_nom");
input2=lookup_widget (objet, "entry_modifier_prenom");
input3=lookup_widget (objet, "entry_modifier_cin");
input4=lookup_widget (objet, "radiobutton_homme_modifier");
input5=lookup_widget (objet, "radiobutton_femme_modifier");
input6=lookup_widget (objet, "comboboxentry_role_modifier");
input7=lookup_widget (objet, "spinbutton_jour_modifier");
input8=lookup_widget (objet, "spinbutton_annee_modifier");
input9=lookup_widget (objet, "spinbutton_mois_modifier");
input10=lookup_widget (objet, "entry_age_modifier");


input11=lookup_widget (objet, "entry_telephone_modifier");
input12=lookup_widget (objet, "entry_email_modifier");
input13=lookup_widget (objet, "entry_adresse_modifier");


strcpy(p.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(p.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(p.cin, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(p.age, gtk_entry_get_text(GTK_ENTRY(input10)));

strcpy(p.telephone, gtk_entry_get_text(GTK_ENTRY(input11)));
strcpy(p.adresse, gtk_entry_get_text(GTK_ENTRY(input13)));
strcpy(p.email, gtk_entry_get_text(GTK_ENTRY(input12)));

p.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
p.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
p.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));



strcpy(p.role, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input6)));

if (y==1)
{
strcpy(p.sexe,"homme");
}
if (y==2)
{
strcpy(p.sexe,"femme");
}
gtk_label_set_text(GTK_LABEL(success),"Modification réuissite"); 

modifier_personne(p);
}


void
on_button_chercher_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{

personne p;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet,"entry_rechercher_CIN");
nonexiste=lookup_widget(objet,"label_rechercher1");


strcpy(p.cin,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_cin(p.cin)==0)
{ 
    gtk_label_set_text(GTK_LABEL(nonexiste),"CIN non existant");
}
else 
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"");
}

chercher_personne(p);
 


gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview1;
treeview1=lookup_widget(objet,"treeview1");
afficher_personne_chercher(treeview1);


}




void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=1;
}


void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=2;
}


void
on_button_supprimer_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
personne p;
char cin1[30],cin2[30];
char n1[30] , n2[30],n3[30],n4[30] ,n5[30] , n6[30],n7[30],n8[30] ,n9[30];
char msg [50];
int trouve=0;
FILE *f,*E ;
input1= lookup_widget (objet, "entry_supprimer_CIN");
strcpy(cin1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("utilisateur.txt","r");
E=fopen("utilisateurtemp.txt","w");
  while (fscanf (f, "%s %s %s %s %s %s %s %s %s %s", &n1,&n2,&cin2, &n3,&n4,&n5,&n6,&n7,&n8,&n9) == 10)
    if (strcmp (cin2, cin1) != 0)
      fprintf (E, "%s %s %s %s %s %s %s %s %s %s\n", n1,n2,cin2, n3,n4,n5,n6,n7,n8,n9);
  fclose(f);
  fclose(E);
f=fopen("utilisateur.txt","w");
E=fopen("utilisateurtemp.txt","r");
  while (fscanf (E, "%s %s %s %s %s %s %s %s %s %s", &n1,&n2,&cin2, &n3,&n4,&n5,&n6,&n7,&n8,&n9) == 10)
      fprintf (f, "%s %s %s %s %s %s %s %s %s %s\n", n1,n2,cin2, n3,n4,n5,n6,n7,n8,n9);
 fclose (f);
 fclose(E);
}


void
on_radiobutton_homme_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=1;
}


void
on_radiobutton_femme_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=2;
}


void
on_button_modifier_rech_clicked        (GtkButton       *objet,
                                        gpointer         user_data)
{
char nom[30];
char prenom[30];
char cin[30];
int jour;
int mois;
int annee;
char date [30];
char age [30] ;
char telephone [30];
char adresse[30];
char email[30];
char role [30];

personne p;
GtkWidget *input1,*input2,*input3,*input4,*input5 ,*input6,*input7 ,*input8,*input9,*input10,*input11,*input12,*input13,*success ;
GtkWidget *fenetre_tableau;

success=lookup_widget(objet,"label_modifier_msg");

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");

input1=lookup_widget (objet, "entry_modifier_nom");
input2=lookup_widget (objet, "entry_modifier_prenom");
input3=lookup_widget (objet, "entry_modifier_cin");
input10=lookup_widget (objet, "entry_age_modifier");
input11=lookup_widget (objet, "entry_telephone_modifier");
input12=lookup_widget (objet, "entry_email_modifier");
input13=lookup_widget (objet, "entry_adresse_modifier");
input7=lookup_widget (objet, "spinbutton_jour_modifier");
input8=lookup_widget (objet, "spinbutton_annee_modifier");
input9=lookup_widget (objet, "spinbutton_mois_modifier");
input6=lookup_widget (objet, "comboboxentry_role_modifier");
strcpy(cin, gtk_entry_get_text(GTK_ENTRY(input3)));

if (exist_cin(cin)==1)
{
rechercheraffiche(nom,prenom,cin,&jour,&mois,&annee,age,telephone,adresse ,email,role);
gtk_entry_set_text(GTK_ENTRY(input1),nom);
gtk_entry_set_text(GTK_ENTRY(input2),prenom);
gtk_entry_set_text(GTK_ENTRY(input10),age);
gtk_entry_set_text(GTK_ENTRY(input11),telephone);
gtk_entry_set_text(GTK_ENTRY(input12),adresse);
gtk_entry_set_text(GTK_ENTRY(input13),email);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input7),jour);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input8),mois);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input9),annee);
if (strcmp(role,"administrateur")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input6),0);
}
if (strcmp(role,"agentfoyer")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input6),1);
}if (strcmp(role,"agentstock")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input6),2);
}if (strcmp(role,"technicien")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input6),3);
}if (strcmp(role,"nutritionist")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input6),4);
}
if (strcmp(role,"agentreclamation")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input6),5);
}
}
}


void
on_button_nagivateur_utilisateurs_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau;
GtkWidget *fenetre_navigateur;
fenetre_navigateur=lookup_widget(objet,"fenetre_navigateur");
gtk_widget_destroy(fenetre_navigateur);
fenetre_tableau=create_fenetre_tableau();
gtk_widget_show(fenetre_tableau);

}


void
on_button_nagivateur_etudiants_clicked (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant;
GtkWidget *fenetre_navigateur;
fenetre_navigateur=lookup_widget(objet,"fenetre_navigateur");
gtk_widget_destroy(fenetre_navigateur);
fenetre_etudiant=create_fenetre_etudiant();
gtk_widget_show(fenetre_etudiant);

}


void
on_button_nagivateur_liste_dalarme_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_liste_dalarme;
GtkWidget *fenetre_navigateur;
fenetre_navigateur=lookup_widget(objet,"fenetre_navigateur");
gtk_widget_destroy(fenetre_navigateur);
fenetre_liste_dalarme=create_fenetre_liste_dalarme();
gtk_widget_show(fenetre_liste_dalarme);

}


void
on_button_retour_utilisateur1_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau;
GtkWidget *fenetre_navigateur;
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);
}


void
on_button_retour_etudiant_clicked      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant;
GtkWidget *fenetre_navigateur;
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
gtk_widget_destroy(fenetre_etudiant);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);
}



void
on_button_retour_listedalarme_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_liste_dalarme;
GtkWidget *fenetre_navigateur;
fenetre_liste_dalarme=lookup_widget(objet,"fenetre_liste_dalarme");
gtk_widget_destroy(fenetre_liste_dalarme);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);

}

void
on_button_ajouter_etudiant_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{

etudiant e;
GtkWidget *input1,*input2,*input3,*input4,*input5 ,*input6,*input7 ,*input8,*input9,*input10,*input11,*input12,*input13,*input14,*success ;
GtkWidget *fenetre_etudiant;

//success=lookup_widget(objet,"label_msg_ajouter_etudiant");

fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");

input1=lookup_widget (objet, "entry_nom_etudiant");
input2=lookup_widget (objet, "entry_prenom_etudiant");
input3=lookup_widget (objet, "entry_identifiant_etudiant");
input4=lookup_widget (objet, "entry_age_etudiant");
input5=lookup_widget (objet, "entry_email_etudiant");

input6=lookup_widget (objet, "spinbutton_jour_etudiant");
input7=lookup_widget (objet, "spinbutton_mois_etudiant");
input8=lookup_widget (objet, "spinbutton_annee_etudiant");

input9=lookup_widget (objet, "radiobutton_homme_etudiant");
input10=lookup_widget (objet, "radiobutton_femme_etudiant");

input11=lookup_widget (objet, "comboboxentry_niveau_etudiant");
input12=lookup_widget (objet, "comboboxentry_filiere_etudiant");

input13=lookup_widget (objet, "entry_telephone_etudiant");
input14=lookup_widget (objet, "entry_adresse_etudiant");

strcpy(e.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.cin, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.age, gtk_entry_get_text(GTK_ENTRY(input4)));
strcpy(e.email, gtk_entry_get_text(GTK_ENTRY(input5)));

e.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
e.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));
e.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));

strcpy(e.filiere, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input11)));
strcpy(e.niveau, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input12)));

strcpy(e.telephone, gtk_entry_get_text(GTK_ENTRY(input13)));
strcpy(e.adresse, gtk_entry_get_text(GTK_ENTRY(input14)));


if (E==1)
{
strcpy(e.sexe,"homme");
}
if (E==2)
{
strcpy(e.sexe,"femme");
}

//gtk_label_set_text(GTK_LABEL(success),"Ajout réuissite");
ajouter_etudiant(e);
}


void
on_radiobutton_femme_etudiant_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
E=2;
}


void
on_radiobutton_homme_etudiant_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
E=1;
}


void
on_treeview2_row_activated             (GtkTreeView     *treeview2,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{

GtkTreeIter iter;
gchar *nom;
gchar *prenom;
gchar *cin;
gchar *sexe;
gchar *role;
etudiant e;
 GtkTreeModel *model=gtk_tree_view_get_model(treeview2);
if (gtk_tree_model_get_iter(model,&iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&nom,1,&prenom,3,&cin,4,&role,-1);
strcpy(e.nom,nom);
strcpy(e.prenom,prenom);
strcpy(e.cin,cin);
strcpy(e.sexe,sexe);


afficher_etudiant(treeview2);
}
}
void
on_button_actualiser_etudiant_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant,*w1;
GtkWidget *treeview2;

GtkNotebook  *notebook3 ;

w1=lookup_widget(objet,"fenetre_etudiant");
fenetre_etudiant=create_fenetre_etudiant();
gtk_widget_show(fenetre_etudiant);
gtk_widget_hide(w1);
treeview2=lookup_widget(fenetre_etudiant,"treeview2");
afficher_etudiant(treeview2);
}


void
on_button_afficher_etudiant_clicked    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant;
GtkWidget *treeview2;

fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
gtk_widget_show(fenetre_etudiant);

treeview2=lookup_widget(fenetre_etudiant,"treeview2");
afficher_etudiant(treeview2);

}


void
on_button_modifier_etudiant_clicked    (GtkButton       *objet,
                                        gpointer         user_data)

{

etudiant e;
GtkWidget *input1,*input2,*input3,*input4,*input5 ,*input6,*input7 ,*input8,*input14,*input10,*input11,*input12,*input13,*success ;
GtkWidget *fenetre_etudiant;


fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");

input1=lookup_widget (objet, "entry_nom_modifier_etudiant");
input2=lookup_widget (objet, "entry_prenom_modifier_etudiant");
input3=lookup_widget (objet, "entry_identifiant_modifier_etudiant");
input4=lookup_widget (objet, "entry_age_modifier_etudiant");
input5=lookup_widget (objet, "entry_email_modifier_etudiant");

input6=lookup_widget (objet, "spinbutton_jour_modifier_etudiant");
input7=lookup_widget (objet, "spinbutton_mois_modifier_etudiant");
input8=lookup_widget (objet, "spinbutton_annee_modifier_etudiant");


input11=lookup_widget (objet, "comboboxentry_niveau_modifier_etudiant");
input12=lookup_widget (objet, "comboboxentry_filiere_modifier_etudiant");

input13=lookup_widget (objet, "entry_telephone_modifier_etudiant");
input14=lookup_widget (objet, "entry_adresse_modifier_etudiant");

strcpy(e.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(e.prenom, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(e.cin, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(e.age, gtk_entry_get_text(GTK_ENTRY(input4)));

strcpy(e.telephone, gtk_entry_get_text(GTK_ENTRY(input13)));
strcpy(e.adresse, gtk_entry_get_text(GTK_ENTRY(input14)));
strcpy(e.email, gtk_entry_get_text(GTK_ENTRY(input5)));

e.d.jour=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
e.d.annee=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
e.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input7));

strcpy(e.filiere, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input12)));
strcpy(e.niveau, gtk_combo_box_get_active_text(GTK_COMBO_BOX(input11)));

if (o==1)
{
strcpy(e.sexe,"homme");
}
if (o==2)
{
strcpy(e.sexe,"femme");
}
modifier_etudiant(e);
}


void
on_button_remplir_etudiant_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{

char nom[30];
char prenom[30];
char cin[30];
char naissance [30];
char age [30] ;
char sexe[30];
char filiere[30];
char niveau[30];
char email[30];
char telephone [30];
char adresse[30];
int jour;
int mois;
int annee;


etudiant e;
GtkWidget *input1,*input2,*input3,*input4,*input5 ,*input6,*input7 ,*input8,*input14,*input10,*input11,*input12,*input13,*success ;
GtkWidget *fenetre_etudiant;


fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");

input1=lookup_widget (objet, "entry_nom_modifier_etudiant");
input2=lookup_widget (objet, "entry_prenom_modifier_etudiant");
input3=lookup_widget (objet, "entry_identifiant_modifier_etudiant");
input4=lookup_widget (objet, "entry_age_modifier_etudiant");
input5=lookup_widget (objet, "entry_email_modifier_etudiant");
input6=lookup_widget (objet, "spinbutton_jour_modifier_etudiant");
input7=lookup_widget (objet, "spinbutton_mois_modifier_etudiant");
input8=lookup_widget (objet, "spinbutton_annee_modifier_etudiant");
input11=lookup_widget (objet, "comboboxentry_niveau_modifier_etudiant");
input12=lookup_widget (objet, "comboboxentry_filiere_modifier_etudiant");
input13=lookup_widget (objet, "entry_telephone_modifier_etudiant");
input14=lookup_widget (objet, "entry_adresse_modifier_etudiant");
strcpy(cin, gtk_entry_get_text(GTK_ENTRY(input3)));

if (exist_etudiant(cin)==1)
{
rempliraffiche(nom,prenom,cin,&jour,&mois,&annee,age,sexe,filiere,niveau,email,telephone,adresse);

if (strcmp(niveau,"1ere")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input11),0);
}
if (strcmp(niveau,"2eme")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input11),1);
}if (strcmp(niveau,"3eme")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input11),2);
}
if (strcmp(niveau,"4eme")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input11),3);
}
if (strcmp(niveau,"5eme")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input11),4);
}
gtk_entry_set_text(GTK_ENTRY(input1),nom);
gtk_entry_set_text(GTK_ENTRY(input2),prenom);
gtk_entry_set_text(GTK_ENTRY(input4),age);
gtk_entry_set_text(GTK_ENTRY(input13),telephone);
gtk_entry_set_text(GTK_ENTRY(input14),adresse);
gtk_entry_set_text(GTK_ENTRY(input5),email);

gtk_spin_button_set_value(GTK_SPIN_BUTTON(input6),jour);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input7),mois);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input8),annee);
if (strcmp(filiere,"informatique")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input12),0);
}
if (strcmp(filiere,"electro")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input12),1);
}if (strcmp(filiere,"geniecivil")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input12),2);
}
}
}

void
on_radiobutton_homme_modifier_etudiant_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
o=1;
}


void
on_radiobutton_femme_modifier_etudiant_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
o=2;
}


void
on_button_supprimer_etudiant_clicked   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
etudiant e;
char cin1[30],cin2[30];
char n1[30] , n2[30],n3[30],n4[30] ,n5[30] , n6[30],n7[30],n8[30] ,n9[30],n10[30];
char msg [50];
int trouve=0;
FILE *f,*E ;
input1= lookup_widget (objet, "entry_supprimer_etudiant");
strcpy(cin1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("etudiantadmin.txt","r");
E=fopen("etudiantadmintemp.txt","w");
  while (fscanf (f, "%s %s %s %s %s %s %s %s %s %s %s", &n1,&n2,&cin2, &n3,&n4,&n5,&n6,&n7,&n8,&n9,&n10) == 11)
    if (strcmp (cin2, cin1) != 0)
      fprintf (E, "%s %s %s %s %s %s %s %s %s %s %s\n", n1,n2,cin2, n3,n4,n5,n6,n7,n8,n9,n10);
  fclose(f);
  fclose(E);
f=fopen("etudiantadmin.txt","w");
E=fopen("etudiantadmintemp.txt","r");
  while (fscanf (E, "%s %s %s %s %s %s %s %s %s %s %s", &n1,&n2,&cin2, &n3,&n4,&n5,&n6,&n7,&n8,&n9,&n10) == 11)
      fprintf (f, "%s %s %s %s %s %s %s %s %s %s %s\n", n1,n2,cin2, n3,n4,n5,n6,n7,n8,n9,n10);
 fclose (f);
 fclose(E);
}


void
on_button_rechercher_etudiant_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{
etudiant e;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet,"entry_rechercher_etudiant");
nonexiste=lookup_widget(objet,"label_rechercher_etudiant");


strcpy(e.cin,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_etudiant(e.cin)==0)
{ 
    gtk_label_set_text(GTK_LABEL(nonexiste),"CIN non existant");
}
else 
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"");
}

chercher_etudiant(e);
 
gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview2;
treeview2=lookup_widget(objet,"treeview2");
afficher_etudiant_chercher(treeview2);


}


void
on_button_ajouter_vers_modifier_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook3 ;
notebook3=(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
gint page = gtk_notebook_get_current_page (notebook3); 
gtk_notebook_set_current_page (notebook3,2);

}


void
on_button_ajouter_vers_afficher_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook3 ;
notebook3=(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
gint page = gtk_notebook_get_current_page (notebook3); 
gtk_notebook_set_current_page (notebook3,1);
}


void
on_button_quitter_ajouter_clicked      (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_afficher_vers_modifier_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook3 ;
notebook3=(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
gint page = gtk_notebook_get_current_page (notebook3); 
gtk_notebook_set_current_page (notebook3,2);
}


void
on_button_afficher_vers_ajouter_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{GtkNotebook  *notebook3 ;
notebook3=(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
gint page = gtk_notebook_get_current_page (notebook3); 
gtk_notebook_set_current_page (notebook3,0);
}


void
on_button_quitter_afficher_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_retour_utilisateur2_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau;
GtkWidget *fenetre_navigateur;
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);
}


void
on_button_quitter_modifier_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_modifier_vers_afficher_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{GtkNotebook  *notebook3 ;
notebook3=(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
gint page = gtk_notebook_get_current_page (notebook3); 
gtk_notebook_set_current_page (notebook3,1);
}


void
on_button_modifier_vers_ajouter_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{GtkNotebook  *notebook3 ;
notebook3=(GTK_NOTEBOOK(lookup_widget(objet,"notebook3")));
gint page = gtk_notebook_get_current_page (notebook3); 
gtk_notebook_set_current_page (notebook3,0);
}


void
on_button_retour_utilisateur3_clicked  (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau;
GtkWidget *fenetre_navigateur;
fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);
}


void
on_button_quitter_navigateur_clicked   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_navigateur ;
GtkWidget *fenetre_dashboard;
fenetre_navigateur=lookup_widget(objet,"fenetre_navigateur");
gtk_widget_destroy(fenetre_navigateur);
fenetre_navigateur=lookup_widget(objet,"fenetre_navigateur");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_ajouter_etudiant_vers_modifier_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook4 ;
notebook4=(GTK_NOTEBOOK(lookup_widget(objet,"notebook4")));
gint page = gtk_notebook_get_current_page (notebook4); 
gtk_notebook_set_current_page (notebook4,2);
}


void
on_button_ajouter_etudiant_vers_afficher_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook4 ;
notebook4=(GTK_NOTEBOOK(lookup_widget(objet,"notebook4")));
gint page = gtk_notebook_get_current_page (notebook4); 
gtk_notebook_set_current_page (notebook4,1);
}


void
on_button_quitter_etudiant1_clicked    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant ;
GtkWidget *fenetre_dashboard;
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
gtk_widget_destroy(fenetre_etudiant);
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_afficher_etudiant_vers_ajouter_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook4 ;
notebook4=(GTK_NOTEBOOK(lookup_widget(objet,"notebook4")));
gint page = gtk_notebook_get_current_page (notebook4); 
gtk_notebook_set_current_page (notebook4,0);
}


void
on_button_afficher_etudiant_vers_modifier_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook4 ;
notebook4=(GTK_NOTEBOOK(lookup_widget(objet,"notebook4")));
gint page = gtk_notebook_get_current_page (notebook4); 
gtk_notebook_set_current_page (notebook4,2);
}


void
on_button_quitter_etudiant3_clicked    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant ;
GtkWidget *fenetre_dashboard;
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
gtk_widget_destroy(fenetre_etudiant);
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_retour_etudiant0_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant;
GtkWidget *fenetre_navigateur;
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
gtk_widget_destroy(fenetre_etudiant);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);
}


void
on_button_quitter_etudiant2_clicked    (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant ;
GtkWidget *fenetre_dashboard;
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
gtk_widget_destroy(fenetre_etudiant);
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_retour_etudiant2_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_etudiant;
GtkWidget *fenetre_navigateur;
fenetre_etudiant=lookup_widget(objet,"fenetre_etudiant");
gtk_widget_destroy(fenetre_etudiant);
fenetre_navigateur=create_fenetre_navigateur();
gtk_widget_show(fenetre_navigateur);
}


void
on_button_modifier_etudiant_vers_ajouter_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook4 ;
notebook4=(GTK_NOTEBOOK(lookup_widget(objet,"notebook4")));
gint page = gtk_notebook_get_current_page (notebook4); 
gtk_notebook_set_current_page (notebook4,0);
}


void
on_button_modifier_etudiant_vers_afficher_clicked
                                        (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkNotebook  *notebook4 ;
notebook4=(GTK_NOTEBOOK(lookup_widget(objet,"notebook4")));
gint page = gtk_notebook_get_current_page (notebook4); 
gtk_notebook_set_current_page (notebook4,1);
}

