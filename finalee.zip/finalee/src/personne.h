#include <gtk/gtk.h>
typedef struct
{
int jour ;
int mois;
int annee;
}date;
typedef struct
{
char nom[30];
char prenom[30];
char cin[30];
date d;
char age [30] ;
char sexe[30];
char telephone [30];
char adresse[30];
char email[30];
char role [30];
}personne;
int y;
int x;
void ajouter_personne(personne p);
void afficher_personne(GtkWidget * liste );
void supprimer_personne(personne p);
void modifier_personne(personne p);
void chercher_personne(personne p) ; 


void afficher_personne_chercher(GtkWidget *liste);
int exist_cin(char* cin);
int verifier_ACCEE_inscrit(char cin[30]);
int verifier_PASSEWORD_inscrit(char passeword[30]);
int verifier_CIN_inscrit(char cin[30]);
void vider(GtkWidget *liste);

void rechercheraffiche(char nom[30],char prenom[30],char cin[30],int *jour,int *mois,int *annee,char age[30],char telephone[30],char adresse[30] ,char email[30],char role[30]);
