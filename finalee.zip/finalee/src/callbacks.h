#include <gtk/gtk.h>


void
on_button_go_to_login_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_login_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_inscription_clicked          (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_actualiser_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_chercher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_femme_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme_clicked           (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_modifier_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modifier_rech_clicked        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_nagivateur_utilisateurs_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_nagivateur_etudiants_clicked (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_nagivateur_liste_dalarme_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_utilisateur1_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_etudiant_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_listedalarme_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_etudiant_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_femme_etudiant_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_homme_etudiant_toggled  (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_treeview2_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);

void
on_button_actualiser_etudiant_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_etudiant_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_etudiant_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_remplir_etudiant_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_homme_modifier_etudiant_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_femme_modifier_etudiant_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_supprimer_etudiant_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_rechercher_etudiant_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_vers_modifier_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_vers_afficher_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_ajouter_clicked      (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_vers_modifier_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_vers_ajouter_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_afficher_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_utilisateur2_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_modifier_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_vers_afficher_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_vers_ajouter_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_utilisateur3_clicked  (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_navigateur_clicked   (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_etudiant_vers_modifier_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_etudiant_vers_afficher_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_etudiant1_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_etudiant_vers_ajouter_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_etudiant_vers_modifier_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_etudiant3_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_etudiant0_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter_etudiant2_clicked    (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_etudiant2_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_etudiant_vers_ajouter_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_modifier_etudiant_vers_afficher_clicked
                                        (GtkButton       *button,
                                        gpointer         user_data);
