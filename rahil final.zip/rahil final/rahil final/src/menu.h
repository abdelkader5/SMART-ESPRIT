#include<gtk/gtk.h>
typedef struct 
{
char id[30];
char type[30];
char plat[30];
char ing[30];
char date[30];
char groupetr[30];
char modetr [30];
int nb; 
}nutri ;

void ajouter_menu(nutri A);
void supp_menu(char id[]);
nutri rech_menu(char id[]);
void modi_menu(char id[], nutri U);
void afficher_menu (GtkWidget *treeview1 ,char *l);

