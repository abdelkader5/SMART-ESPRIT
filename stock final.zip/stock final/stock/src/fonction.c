#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gtk/gtk.h> 
#include "fonction.h"
enum{
NOM,
ID,
PRIX,
QUANTITE,
CATEGORIE,
DATE,
T,
COLUMNS
};

void ajouter_stock(stock s)
{
FILE *f;
f=fopen("stock.txt","a+");
if (f!=NULL)
{
fprintf(f,"%s %s %s %s %s %d/%d %s\n",s.nom,s.id,s.prix,s.quantite,s.categorie,s.d.mois,s.d.anne,s.t);
}
fclose(f);
}

void afficher_stock(GtkWidget * liste ){

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter iter;
GtkListStore *store;

char nom [20];
char id [20];
char prix [20];
char quantite[20];
char categorie[20];
char date[20];
char t[50];
store=NULL;
FILE *f;
store=gtk_tree_view_get_model(liste);
if(store==NULL)
{

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("nom",renderer,"text",NOM,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("id",renderer,"text",ID,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("prix",renderer,"text",PRIX,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("quantite",renderer,"text",QUANTITE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("categorie",renderer,"text",CATEGORIE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("date",renderer,"text",DATE,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

renderer=gtk_cell_renderer_text_new();
column=gtk_tree_view_column_new_with_attributes("t",renderer,"text",T,NULL);
gtk_tree_view_append_column(GTK_TREE_VIEW(liste),column);

store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);

f=fopen("stock.txt","r");
if(f==NULL)
{
return;
}
else
{f=fopen("stock.txt","a+");
while(fscanf(f,"%s %s %s %s %s %s %s\n",nom,id,prix,quantite,categorie,date,t)!=EOF)
{
gtk_list_store_append(store,&iter);
gtk_list_store_set(store,&iter,NOM,nom,ID,id,PRIX,prix,QUANTITE,quantite,CATEGORIE,categorie,DATE,date,T,t,-1);
}
fclose(f);
gtk_tree_view_set_model(GTK_TREE_VIEW(liste),GTK_TREE_MODEL(store));
g_object_unref(store);
}
}
}

void vider(GtkWidget *liste)
{

GtkCellRenderer *renderer;
GtkTreeViewColumn *column;
GtkTreeIter	iter;
GtkListStore *store;
	
char nom[30];
char id[30];
char prix[30];
char quantite[30];
char categorie[30];
store=NULL ;

FILE *f;

store=gtk_tree_view_get_model(liste);
if (store==NULL)
	{
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" nom ", renderer , "text",nom, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" id ", renderer , "text",id, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" prix ", renderer , "text",prix, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
		
		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" quantite ", renderer , "text",quantite, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

		renderer = gtk_cell_renderer_text_new ();
		column = gtk_tree_view_column_new_with_attributes(" categorie ", renderer , "text",categorie, NULL);
		gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);

}

store=gtk_list_store_new (COLUMNS, G_TYPE_STRING, G_TYPE_STRING,G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING, G_TYPE_STRING);
gtk_list_store_append (store, &iter);
gtk_tree_view_set_model (GTK_TREE_VIEW (liste), GTK_TREE_MODEL (store));

}


void chercher_stock(stock s)  
{
FILE* f;
FILE* f1;
	char nom[30];
	char id[30];
	char prix[30];
        char quantite[30];
	char categorie[30];
	char date[20];
	char t[50];

f=fopen("stock.txt","r");
f1=fopen("stockchercher.txt","w");
  while(fscanf(f,"%s %s %s %s %s %s %s \n",nom,id,prix,quantite,categorie,date,t)!=EOF)
{
if (strcmp(s.id,id)==0)
{
fprintf(f1,"%s %s %s %s %s %s %s\n",nom,id,prix,quantite,categorie,date,t);
}
}
fclose(f);
fclose(f1);
}

void afficher_stock_chercher(GtkWidget *liste)
{
      GtkCellRenderer *renderer;
	GtkTreeViewColumn *column;
	GtkTreeIter iter;
	GtkListStore *store;

	char nom[30];
	char id[30];
	char prix[30];
        char quantite[30];
	char categorie[30];
	char date[30];
	char t[50];

	store=NULL;
	
	FILE *f;
 
	store=gtk_tree_view_get_model(liste);

	if(store==NULL)
	{
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("nom", renderer,"text",NOM,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("id", renderer,"text",ID,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("prix", renderer,"text",PRIX,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("quantite", renderer,"text",QUANTITE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
        renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("categorie", renderer,"text",CATEGORIE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	renderer = gtk_cell_renderer_text_new ();
        renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("date", renderer,"text",DATE,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
        renderer = gtk_cell_renderer_text_new ();
	column = gtk_tree_view_column_new_with_attributes("t", renderer,"text",T,NULL);
	gtk_tree_view_append_column (GTK_TREE_VIEW (liste), column);
	}
		store=gtk_list_store_new(COLUMNS,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING,G_TYPE_STRING);
	f = fopen("stockchercher.txt","r");
	if(f==NULL)
	{
	return;
	}
	else
	{
	 f=fopen("stockchercher.txt","a+");
		while(fscanf(f,"%s %s %s %s %s %s %s\n",nom,id,prix,quantite,categorie,date,t)!=EOF)
		{
		gtk_list_store_append(store,&iter);
		 gtk_list_store_set(store,&iter ,NOM,nom,ID,id,PRIX,prix,QUANTITE,quantite,CATEGORIE,categorie,DATE,date,T,t,-1);		
		}
		fclose(f);
		gtk_tree_view_set_model(GTK_TREE_VIEW(liste), GTK_TREE_MODEL(store));
		g_object_unref(store);

	}
}
//verifier l'existance 
int exist_id(char* id){
FILE*f=NULL;
stock s;
f=fopen("stock.txt","r");// ouverture du fichier plante en  mode lecture 
while(fscanf(f,"%s %s %s %s %s \n",s.nom,s.id,s.prix,s.quantite,s.categorie)!=EOF){
if(strcmp(s.id,id)==0)
return 1;   //id existe deja 
}
fclose(f);
return 0;
}

void modifier_stock(stock s)
{
FILE *f;
FILE *t;

stock z ;
f=fopen("stock.txt","r");
t=fopen("temp.text","a");

    if (f!=NULL || t!=NULL)
    {
/*printf("Donnez la id de l'employe a modifie: \n");
    scanf("%s",s.id);*/
    while(fscanf(f,"%s %s %s %s %s %d/%d %s\n",z.nom,z.id,z.prix,z.quantite,z.categorie,&z.d.mois,&z.d.anne,z.t)!=EOF)
    {

if(strcmp(z.id,s.id)==0)
        {
fprintf(t,"%s %s %s %s %s %d/%d %s\n",s.nom,s.id,s.prix,s.quantite,s.categorie,s.d.mois,s.d.anne,s.t);
}
else
fprintf(t,"%s %s %s %s %s %d/%d %s\n",z.nom,z.id,z.prix,z.quantite,z.categorie,z.d.mois,z.d.anne,z.t);
    }
    }

fclose(t);
fclose(f);
remove("stock.txt");
rename("temp.text","stock.txt");
}

void rechercheraffiche(char nom[],char id[],char prix[],char quantite[],char categorie[] ,int *mois,int *anne,char t[]){
 stock s ;
FILE *f;
    f=fopen("stock.txt", "r");
   
    while(fscanf(f,"%s %s %s %s %s %d/%d %s \n",s.nom,s.id,s.prix,s.quantite,s.categorie,&s.d.mois,&s.d.anne,s.t)!=EOF)
{
        if(strcmp(s.id,id)==0) { strcpy(nom,s.nom);
strcpy(id,s.id);
strcpy(prix,s.prix);
strcpy(quantite,s.quantite);
strcpy(categorie,s.categorie);
mois=&s.d.mois;
anne=&s.d.anne;
// sprintf(date,"%d/%d/%d",s.d.jour,s.d.mois,s.d.annee);
// printf("%s",date);
strcpy(t,s.t);
break;

}



}
fclose(f);
}

