#include <gtk/gtk.h>
typedef struct
{
int mois;
int anne;
}date;

typedef struct
{
char nom[20];
char id[20];
char prix[20];
char quantite[20];
char categorie[30];
date d;
char t[50];
}stock;
int y;
int x;
void ajouter_stock(stock s);
void afficher_stock(GtkWidget * liste );
void supprimer_stock(stock s);
void modifier_stock(stock s);
void chercher_stock(stock s);
void afficher_stock_chercher(GtkWidget *liste);
void vider(GtkWidget *liste);
int exist_id(char* id);
void rechercheraffiche(char nom[20],char id[20],char prix[20],char quantite[20],char categorie[30] ,int *mois,int *anne,char t[50]);
