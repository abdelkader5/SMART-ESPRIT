#include <gtk/gtk.h>


void
on_button_valide_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_login_clicked                (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter1_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_retour_clicked               (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter2_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter3_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter4_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_quitter5_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_ajouter_clicked              (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_afficher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data);


void
on_button_chercher_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_supprimer_clicked            (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_viande_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_boisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_modifier_clicked             (GtkButton       *button,
                                        gpointer         user_data);

void
on_radiobutton_modifier_viande_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modifier_boisson_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_radiobutton_modifier_legume_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data);

void
on_button_remplir_modifier_clicked     (GtkButton       *button,
                                        gpointer         user_data);

void
on_button_actualiser_stock_clicked     (GtkButton       *button,
                                        gpointer         user_data);
