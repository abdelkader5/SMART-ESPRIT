#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>

#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"


void
on_button_valide_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_login ;
GtkWidget *fenetre_dashboard;

fenetre_dashboard=lookup_widget(objet,"fenetre_dashboard");
gtk_widget_destroy(fenetre_dashboard);
fenetre_dashboard=lookup_widget(objet,"fenetre_dashboard");
fenetre_login=create_fenetre_login();
gtk_widget_show(fenetre_login);
}


void
on_button_login_clicked                (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_login ;
GtkWidget *fenetre_tableau;

fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);

fenetre_tableau=create_fenetre_tableau();
gtk_widget_show(fenetre_tableau);
}


void
on_button_quitter1_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);

fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_retour_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_login ;
GtkWidget *fenetre_dashboard;

fenetre_login=lookup_widget(objet,"fenetre_login");
gtk_widget_destroy(fenetre_login);

fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}


void
on_button_quitter2_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);

fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}



void
on_button_quitter3_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);

fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}



void
on_button_quitter4_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);

fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}



void
on_button_quitter5_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau ;
GtkWidget *fenetre_dashboard;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_destroy(fenetre_tableau);

fenetre_dashboard=create_fenetre_dashboard();
gtk_widget_show(fenetre_dashboard);
}



void
on_button_ajouter_clicked              (GtkButton       *objet,
                                        gpointer         user_data)
{
stock s;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*input8,*input9,*input10,*success;
GtkWidget *fenetre_tableau;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");

input1=lookup_widget (objet, "entry_nom");
input2=lookup_widget (objet, "entry_id");
input3=lookup_widget (objet, "entry_prix");
input4=lookup_widget (objet, "entry_quantite");
input5=lookup_widget (objet, "radiobutton_viande");
input6=lookup_widget (objet, "radiobutton_fruit");
input7=lookup_widget (objet, "radiobutton_boisson");
input8=lookup_widget (objet, "spinbutton_date_mois");
input9=lookup_widget (objet, "spinbutton_date_anne"); 
input10=lookup_widget (objet, "comboboxentry_stock1");

strcpy(s.nom, gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(s.id, gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(s.prix, gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(s.quantite, gtk_entry_get_text(GTK_ENTRY(input4)));

s.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input8));
s.d.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input9));

strcpy(s.t,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input10)));


if (x==1)
{
strcpy(s.categorie,"viande/poisson/poulet");
}
if (x==2)
{
strcpy(s.categorie,"fruit/legumes");
}
if (x==3)
{
strcpy(s.categorie,"boisson");
}

gtk_label_set_text(GTK_LABEL(success),"Ajout réuissite");

ajouter_stock(s);
}


void
on_button_afficher_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau;
GtkWidget *treeview1;

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");
gtk_widget_show(fenetre_tableau);

treeview1=lookup_widget(fenetre_tableau,"treeview1");

afficher_stock(treeview1);
}


void
on_treeview1_row_activated             (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar *nom;
gchar *id;
gchar *prix;
gchar *quantite;
gchar *categorie;
stock s;


 GtkTreeModel *model=gtk_tree_view_get_model(treeview);
if (gtk_tree_model_get_iter(model,&iter ,path))
{
gtk_tree_model_get (GTK_LIST_STORE(model),&iter,0,&nom,1,&id,3,&prix,4,&quantite,5,&categorie,-1);
strcpy(s.nom,nom);
strcpy(s.id,id);
strcpy(s.prix,prix);
strcpy(s.quantite,quantite);
strcpy(s.categorie,categorie);

afficher_stock(treeview);
}
}



void
on_button_chercher_clicked             (GtkButton       *objet,
                                        gpointer         user_data)
{
stock s;
GtkWidget *input11;
GtkWidget *nonexiste;

input11=lookup_widget(objet,"entry_id_chercher");
nonexiste=lookup_widget(objet,"label_chercher_fergha");


strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(input11)));

if (exist_id(s.id)==0)
{ 
    gtk_label_set_text(GTK_LABEL(nonexiste),"ID non existant");
}
else 
{
    gtk_label_set_text(GTK_LABEL(nonexiste),"");
}

chercher_stock(s);
 


gtk_entry_set_text(GTK_ENTRY(input11),"");
GtkWidget *treeview1;
treeview1=lookup_widget(objet,"treeview1");
afficher_stock_chercher(treeview1);
}


void
on_button_supprimer_clicked            (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *input1, *output;
stock s;
char id1[20],id2[20];
char n1[20] , n2[20],n3[20] ,n4[20],n5[20],n6[50];
char msg [50];
int trouve=0;
FILE *f,*E ;
input1= lookup_widget (objet, "entry_id_supprimer");
strcpy(id1, gtk_entry_get_text(GTK_ENTRY(input1)));
f=fopen("stock.txt","r");
E=fopen("stocktemp.txt","w");
  while (fscanf (f, "%s %s %s %s %s %s %s", &n1,&id2,&n2, &n3,&n4,&n5,&n6) == 7)
    if (strcmp (id2, id1) != 0)
      fprintf (E, "%s %s %s %s %s %s %s\n", n1,id2,n2, n3,n4,n5,n6);
  fclose(f);
  fclose(E);
f=fopen("stock.txt","w");
E=fopen("stocktemp.txt","r");
  while (fscanf (E, "%s %s %s %s %s %s %s", &n1,&id2,&n2, &n3,&n4,&n5,&n6) == 7)
      fprintf (f, "%s %s %s %s %s %s %s\n", n1,id2,n2, n3,n4,n5,n6);
 fclose (f);
 fclose(E);
}


void
on_radiobutton_viande_toggled          (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=1;
}


void
on_radiobutton_fruit_toggled           (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=2;
}


void
on_radiobutton_boisson_toggled         (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
x=3;
}


void
on_button_modifier_clicked             (GtkButton       *objet_graphique,
                                        gpointer         user_data)
{
stock s;


GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*success;

input1=lookup_widget(objet_graphique,"entry_modifier_nom");
input2=lookup_widget(objet_graphique,"entry_modifier_id");
input3=lookup_widget(objet_graphique,"entry_modifier_prix");
input4=lookup_widget(objet_graphique,"entry_modifier_quantite");
input5=lookup_widget(objet_graphique,"spinbutton_date_mois2");
input6=lookup_widget(objet_graphique,"spinbutton_date_anne2");
input7=lookup_widget(objet_graphique,"comboboxentry2");

success=lookup_widget(objet_graphique,"label_modifier_msg");

strcpy(s.nom,gtk_entry_get_text(GTK_ENTRY(input1)));
strcpy(s.id,gtk_entry_get_text(GTK_ENTRY(input2)));
strcpy(s.prix,gtk_entry_get_text(GTK_ENTRY(input3)));
strcpy(s.quantite,gtk_entry_get_text(GTK_ENTRY(input4)));

s.d.mois=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input5));
s.d.anne=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(input6));
strcpy(s.t,gtk_combo_box_get_active_text(GTK_COMBO_BOX(input7)));

if (y==1)
{
strcpy(s.categorie,"viande/poisson/poulet");
}
if (y==2)
{
strcpy(s.categorie,"fruit/legumes");
}
if (y==3)
{
strcpy(s.categorie,"boisson");
}
gtk_label_set_text(GTK_LABEL(success),"Modification réuissite"); 

modifier_stock(s);
}


void
on_radiobutton_modifier_viande_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=1;
}


void
on_radiobutton_modifier_boisson_toggled
                                        (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=3;
}


void
on_radiobutton_modifier_legume_toggled (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
y=2;
}


void
on_button_remplir_modifier_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
  char nom[30];
	char id[30];
	char prix[30];
        char quantite[30];
	char categorie[30];
	char date[30];
	char t[50];
	int mois;
	int anne;

stock s;
GtkWidget *input1,*input2,*input3,*input4,*input5,*input6,*input7,*success ;
GtkWidget *fenetre_tableau;

success=lookup_widget(objet,"label_modifier_msg");

fenetre_tableau=lookup_widget(objet,"fenetre_tableau");

input1=lookup_widget (objet, "entry_modifier_nom");
input2=lookup_widget (objet, "entry_modifier_id");
input3=lookup_widget (objet, "entry_modifier_prix");
input4=lookup_widget (objet, "entry_modifier_quantite");
input5=lookup_widget (objet, "spinbutton_date_mois2");
input6=lookup_widget (objet, "spinbutton_date_anne2");
input7=lookup_widget (objet, "comboboxentry2");
strcpy(id, gtk_entry_get_text(GTK_ENTRY(input2)));

if (exist_id(id)==1)
{
rechercheraffiche(nom,id,prix,quantite,categorie,&mois,&anne,t);
//sscanf(date,"%d/%d/%d",&jour,&mois,&annee);
gtk_entry_set_text(GTK_ENTRY(input1),nom);
gtk_entry_set_text(GTK_ENTRY(input2),id);
gtk_entry_set_text(GTK_ENTRY(input3),prix);
gtk_entry_set_text(GTK_ENTRY(input4),quantite);

gtk_spin_button_set_value(GTK_SPIN_BUTTON(input5),mois);
gtk_spin_button_set_value(GTK_SPIN_BUTTON(input6),anne);
if (strcmp(t,"Enstock")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input7),0);
}
if (strcmp(t,"Repturedestock")==0)
{
gtk_combo_box_set_active(GTK_COMBO_BOX(input7),1);
}
}
}      




void
on_button_actualiser_stock_clicked     (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *fenetre_tableau,*w1;
GtkWidget *treeview1;

w1=lookup_widget(objet,"fenetre_tableau");
fenetre_tableau=create_fenetre_tableau();

gtk_widget_show(fenetre_tableau);

gtk_widget_hide(w1);

treeview1=lookup_widget(fenetre_tableau,"treeview1");

afficher_stock(treeview1);
}

