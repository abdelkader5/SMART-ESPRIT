#include <gtk/gtk.h>
typedef struct
{char nom [20];
char prenom[20];
char classe[20];
char mail[20];
char id[20];
char adresse[20] ;
char TelMobile[20] ;
char TelParent[20] ;
char nchambre[20] ;
char sexe[20];
char type[20] ;
char etage[20];
//char pay[20];
//char ann[20];
}hebergement;
hebergement h;
void ajouter();
void afficher(GtkWidget * liste);
void modifier(h);
void supprimer(h);
void rechercher (h);
void vider(GtkWidget *liste);
int exist (char id [20]);
int nombre_etudiants (char etagenv[20]);
