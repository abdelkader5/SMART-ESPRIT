#ifdef HAVE_CONFIG_H
#  include <config.h>
#endif

#include <gtk/gtk.h>
#include <stdio.h>
#include <stdlib.h>
#include<string.h>
#include "callbacks.h"
#include "interface.h"
#include "support.h"
#include "fonction.h"
int x,p,a,f,d;
//auth ou inscript

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

///AJOUT//////////////////////////////////////////////
/*void
on_buttonAjouter_clicked               (GtkButton       *objet,
                                        gpointer         user_data)
{
capteur c;
FILE *f=NULL;
GtkWidget *ref, *nom, *output,*max,*min;
GtkWidget *combobox1;
char ref1[100];
char nom1[100];
char msg[100];
char T[100];
char R[100];
int trouve=0;


ref = lookup_widget (objet, "entry1");
nom = lookup_widget (objet, "entry2");
combobox1=lookup_widget (objet, "combobox1");
max=lookup_widget(objet,"max");
min=lookup_widget(objet,"min");

strcpy(c.reference_capteur, gtk_entry_get_text(GTK_ENTRY(ref)));

trouve=verifier(c.reference_capteur);

if (trouve==0)
{

if(strcmp("Temperature",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(T,"capteurTemperature");
else if (strcmp("Debit Eau",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(T,"capteurDebitEau");
else if (strcmp("Fumee",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(T,"capteurFumee");
else if (strcmp("Mouvement",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(T,"capteurMouvement");
else if (strcmp("Autre",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox1)))==0)
strcpy(T,"Autre");
c.min = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(min));
c.max = gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(max));


strcpy(c.typeCapteur, T);
strcpy(c.nom_capteur, gtk_entry_get_text(GTK_ENTRY(nom)));

ajouter_capteur (c);

output = lookup_widget(objet, "label93msgajout");
strcpy (msg,"Parfait ! le capteur est bien ajouté");
gtk_label_set_text(GTK_LABEL(output),msg);
}

else 
{
output = lookup_widget(objet, "label93msgajout");
strcpy (msg,"Erreur ! le capteur existe déjà.");
gtk_label_set_text(GTK_LABEL(output),msg);
}

}


void
on_button11_Retour_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard;

Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

Dashboard = create_Dashboard ();
gtk_widget_show (Dashboard) ;
}
*/
///MODIFIER///////////////////////////////
void
on_radiobutton1_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=1;
}


void
on_radiobutton2_toggled                (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=2;
}


void
on_checkbutton1_Type_modif_toggled     (GtkToggleButton *togglebutton,
                                        gpointer         user_data)
{
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton)))
x=3;
}


void
on_button15_modifier_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
FILE *f,*E;
GtkWidget *ref, *nom, *output,*R,*m,*mm;
GtkWidget *combobox2;
GtkWidget * togglebutton1, * togglebutton2,* togglebutton3;
char ref1[100];
char ref2[100];
char nom1[100];
char r[100];
char n[100];
char msg[100];
char T[100];
char T1[100];
int min,max;
int minmodif,maxmodif;
int trouve=0,test=0;
R = lookup_widget(button, "entry13");
output = lookup_widget(button, "labelmsgmodification");
ref = lookup_widget (button, "entry14");
nom = lookup_widget (button, "entry15");
combobox2=lookup_widget (button, "combobox2");
togglebutton1=lookup_widget(button, "radiobutton1");
togglebutton2=lookup_widget(button, "radiobutton2");
togglebutton3=lookup_widget(button, "checkbutton1_Type_modif");
m=lookup_widget(button,"spinbuttonmax");
mm=lookup_widget(button,"spinbuttonmin");
strcpy(ref2, gtk_entry_get_text(GTK_ENTRY(R)));
minmodif=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(mm));
maxmodif=gtk_spin_button_get_value_as_int(GTK_SPIN_BUTTON(m));
//kan radio1 yi5dem
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton1)))
{
strcpy(ref1, gtk_entry_get_text(GTK_ENTRY(ref)));

trouve=verifier(ref2);

test=verifier(ref1);


if ((test==0) && (trouve==1))
{

f=fopen("listecapteur.txt","r+"); 
E=fopen("temporaire.txt","w+"); 
while(fscanf(f,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
       { if(strcmp(r,ref2)==0)
fprintf(E,"%s %s %s %d %d\n",ref1,n,T,maxmodif,minmodif);
else fprintf(E,"%s %s %s %d %d\n",r,n,T,max,min);
	 }
fclose(E);
fclose(f);

E=fopen("temporaire.txt","r"); 
f=fopen("listecapteur.txt","w+");
while(fscanf(E,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
      { 
fprintf(f,"%s %s %s %d %d\n",r,n,T,max,min);
	 }
	fclose(f);
   fclose(E);

strcpy (msg,"Parfait ! la reference est modifié");
}

else 
{
strcpy (msg,"Erreur ! ");
}

gtk_label_set_text(GTK_LABEL(output),msg);


}
//kan radio2 yi5dim
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton2)))
{strcpy(nom1, gtk_entry_get_text(GTK_ENTRY(nom)));//yi7adhar mel entry yi7oto nom1

trouve=0;
trouve=verifier(ref2);

if (trouve==1)//kan l9ah
{

f=fopen("listecapteur.txt","r+"); 
E=fopen("temporaire.txt","w+"); 
while(fscanf(f,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
       { if(strcmp(r,ref2)==0) 
fprintf(E,"%s %s %s %d %d\n",r,nom1,T,maxmodif,minmodif);
else fprintf(E,"%s %s %s %d %d\n",r,n,T,max,min);
	 }
fclose(E);
fclose(f);//c bon tiktib fi E


E=fopen("temporaire.txt","r+"); 
f=fopen("listecapteur.txt","w+");
while(fscanf(E,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
      { 
fprintf(f,"%s %s %s %d %d\n",r,n,T,max,min);//badalna
	 }
	fclose(f);
   fclose(E);

strcpy (msg,"Parfait ! le nom est modifié");
}

else 
{
strcpy (msg,"Erreur ! ");
}

gtk_label_set_text(GTK_LABEL(output),msg);//message
}



//kan radiocheck yi5dem
if (gtk_toggle_button_get_active(GTK_RADIO_BUTTON (togglebutton3)))
{//yi7adher les valeur fi T1
if(strcmp("Temperature",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox2)))==0)
strcpy(T1,"capteurTemperature");
else if (strcmp("Debit Eau",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox2)))==0)
strcpy(T1,"capteurDebitEau");
else if (strcmp("Fumee",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox2)))==0)
strcpy(T1,"capteurFumee");
else if (strcmp("Mouvement",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox2)))==0)
strcpy(T1,"capteurMouvement");
else if (strcmp("Autre",gtk_combo_box_get_active_text (GTK_COMBO_BOX (combobox2)))==0)
strcpy(T1,"Autre");

trouve=0;
trouve=verifier(ref2);
//kan l9ah ***********
if (trouve==1)
{

f=fopen("listecapteur.txt","r+"); 
E=fopen("temporaire.txt","w+"); 
while(fscanf(f,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
       { if(strcmp(r,ref2)==0) //yo93ad yilawej
fprintf(E,"%s %s %s %d %d\n",r,n,T1,maxmodif,minmodif);//l9ah yibadel valeur
else fprintf(E,"%s %s %s %d %d\n",r,n,T,max,min);//yiktbo hoa bido
	 }
fclose(E);
fclose(f);

E=fopen("temporaire.txt","r+"); 
f=fopen("listecapteur.txt","w+");
while(fscanf(E,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
      { 
fprintf(f,"%s %s %s %d %d\n",r,n,T,max,min);
	 }
	fclose(f);
   fclose(E);

strcpy (msg,"Parfait ! le type du capteur modifié");
}

else 
{
strcpy (msg,"Erreur ! ");
}

gtk_label_set_text(GTK_LABEL(output),msg);

}
}


void
on_button4_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard;

Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

Dashboard = create_Dashboard ();
gtk_widget_show (Dashboard) ;
}

//////////CHERCHER///////////////////////////////////////////////////////////////
void
on_button16_chercher_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ref, *output;
FILE *f=NULL;
char ref1[100];
char r[100];
char n[100];
char msg[100];

char T[100];
int trouve=0,max,min;
ref = lookup_widget (button, "entry16");
strcpy(ref1, gtk_entry_get_text(GTK_ENTRY(ref)));
output = lookup_widget(button, "label94msgchercher");

trouve=verifier(ref1);

if (trouve==0)
{
strcpy (msg,"Erreur ! le capteur n'existe pas");
gtk_label_set_text(GTK_LABEL(output),msg);
}

else{
f=fopen("listecapteur.txt","r");  
if(f!=NULL){
while(fscanf(f,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF) 
{

if(strcmp(ref1,r)==0) 
sprintf(msg,"La référence du capteur : %s \n \nLe numéro : %s \n \nLe type : %s\n ",r,n,T);}
fclose(f);}
gtk_label_set_text(GTK_LABEL(output),msg);
}
}


void
on_button17_verifier_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
int trouve=0;
GtkWidget *ref, *output;
char ref1[100];
char msg[100];
ref = lookup_widget (button, "entry16");
strcpy(ref1, gtk_entry_get_text(GTK_ENTRY(ref)));
output = lookup_widget(button, "label49");

trouve=verifier(ref1);

if(trouve==1)
{strcpy (msg,"Le capteur existe, vous pouvez continuer.");
gtk_label_set_text(GTK_LABEL(output),msg);
}
else if(trouve==0){
strcpy (msg,"le capteur n'existe pas, veuillez vérifier.");
gtk_label_set_text(GTK_LABEL(output),msg);}
}


void
on_button5_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard;

Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

Dashboard = create_Dashboard ();
gtk_widget_show (Dashboard) ;
}

//////////////SUPPRIMER//////////////////////////////////////////////////////////
void
on_button18_supprimer_clicked          (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *ref, *output;
char ref1[100];
char msg[200];
char r[100];
char n[100];
char T[100];
int min,max;
FILE *f,*E;
int trouve=0;

ref = lookup_widget (button, "entry7");
strcpy(ref1, gtk_entry_get_text(GTK_ENTRY(ref)));
output = lookup_widget(button, "labelmsgsuppression");
trouve=verifier(ref1);

if (trouve==0)
{
strcpy (msg,"Erreur ! le capteur n'existe pas");
gtk_label_set_text(GTK_LABEL(output),msg);
}

else {

f=fopen("listecapteur.txt","r"); 
E=fopen("temporaire.txt","w+"); 
while(fscanf(f,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
       { if (strcmp(ref1,r)!=0)
fprintf(E,"%s %s %s %d %d\n",r,n,T,max,min);
	 }fclose(f);
	fclose(E);

E=fopen("temporaire.txt","r");
f=fopen("listecapteur.txt","w"); 
while(fscanf(E,"%s %s %s %d %d\n",r,n,T,&max,&min)!=EOF)
      { 
fprintf(f,"%s %s %s %d %d\n",r,n,T,max,min);
	 }
	fclose(f);
   fclose(E);


strcpy (msg,"Parfait ! le capteur est bien supprimé");
gtk_label_set_text(GTK_LABEL(output),msg);

}
}


void
on_button6_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard;

Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

Dashboard = create_Dashboard ();
gtk_widget_show (Dashboard) ;
}

/////////////LISTE/////////////////////////////////
void
on_button7_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard;

Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

Dashboard = create_Dashboard ();
gtk_widget_show (Dashboard) ;
}


void
on_button12_affListe_clicked           (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard,*Liste,*treeview;

Liste = create_Liste();
gtk_widget_show (Liste) ;
Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

treeview=lookup_widget(Liste,"treeview1_Liste");
afficher_capteur (treeview);
}

////////////HISTORIQUE////////////////////////////////
void
on_button8_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard;

Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

Dashboard = create_Dashboard ();
gtk_widget_show (Dashboard) ;
}


void
on_button13_Histo_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard,*Historique,*treeview;

Historique = create_Historique();
gtk_widget_show (Historique) ;
Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

treeview=lookup_widget(Historique,"treeview2_Histo");
afficher_capteur_his(treeview);
}

//////////CAPTDEFFECTUEUX////////////////////////////////
void
on_button14_affdeff_clicked            (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard,*capteurDeffectueux,*treeview;

capteurDeffectueux = create_capteurDeffectueux();
gtk_widget_show (capteurDeffectueux) ;
Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

treeview=lookup_widget(capteurDeffectueux,"treeview3_captDeff");
afficher_capteur_deff(treeview);
}


void
on_button9_Retour_clicked              (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard;

Dashboard=lookup_widget(button,"Dashboard");
gtk_widget_destroy(Dashboard);

Dashboard = create_Dashboard ();
gtk_widget_show (Dashboard) ;
}
///////////////LISTE TREE////////////////////////

void
on_treeview1_Liste_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* ref;
gchar* nom;
gchar* type;
gchar* max;
gchar* min;
capteur c;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter, path)) {

gtk_tree_model_get (GTK_LIST_STORE(model), &iter,0, &ref,1,&nom,2,&type,3,&min,4,&max,-1);

strcpy(c.reference_capteur,ref);
strcpy(c.nom_capteur,nom);
strcpy(c.typeCapteur,type);
strcpy(c.max,max);
strcpy(c.min,min);
//supprim_capteur(c);
afficher_capteur (treeview);
}
}


void
on_button19_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard,*Liste;

Dashboard = create_Dashboard();
gtk_widget_show (Dashboard) ;
Liste=lookup_widget(button,"Liste");
gtk_widget_destroy(Liste);
}

///////////HISTORIQUE TREE//////////////////////////////
void
on_treeview2_Histo_row_activated       (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* jr;
gchar* hr;
gchar* num;
gchar* val;
temp T2;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter, path)) {

gtk_tree_model_get (GTK_LIST_STORE(model), &iter,0, &jr,1,&hr,2,&num,3,&val,-1);

strcpy(T2.jour,jr);
strcpy(T2.heure,num);
strcpy(T2.numT,num);
strcpy(T2.t,val);

afficher_capteur_his(treeview);
}
}


void
on_button20_retour_clicked             (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard,*Historique;

Dashboard = create_Dashboard();
gtk_widget_show (Dashboard) ;
Historique=lookup_widget(button,"Historique");
gtk_widget_destroy(Historique);
}

///////////////////CAPTDEFF TREE///////////////////////////////
void
on_treeview3_captDeff_row_activated    (GtkTreeView     *treeview,
                                        GtkTreePath     *path,
                                        GtkTreeViewColumn *column,
                                        gpointer         user_data)
{
GtkTreeIter iter;
gchar* jr;
gchar* hr;
gchar* num;
gchar* val;
temp T1;

GtkTreeModel *model = gtk_tree_view_get_model(treeview);

if (gtk_tree_model_get_iter(model, &iter, path)) {

gtk_tree_model_get (GTK_LIST_STORE(model), &iter,0, &jr,1,&hr,2,&num,3,&val,-1);

strcpy(T1.jour,jr);
strcpy(T1.heure,hr);
strcpy(T1.numT,num);
strcpy(T1.t,val);

afficher_capteur_deff(treeview);
}
}


void
on_button21_clicked                    (GtkButton       *button,
                                        gpointer         user_data)
{
GtkWidget *Dashboard,*capteurDeffectueux;

Dashboard = create_Dashboard();
gtk_widget_show (Dashboard) ;
capteurDeffectueux=lookup_widget(button,"capteurDeffectueux");
gtk_widget_destroy(capteurDeffectueux);
}




/////////////////ACTUALISER/////////////////////////////////////////////////////////
void
on_button23_actualiser_Liste_clicked   (GtkButton       *objet,
                                        gpointer         user_data)
{
GtkWidget *Liste;
GtkWidget *treeview6;


Liste=lookup_widget(objet,"Liste");

treeview6=lookup_widget(Liste,"treeview1_Liste");

afficher_capteur(treeview6);
}


void
on_button22_actualiser_Histo_clicked   (GtkButton       *button,
                                        gpointer         user_data)
{

}


void
on_button24_act_captdeff_clicked       (GtkButton       *button,
                                        gpointer         user_data)
{

}

